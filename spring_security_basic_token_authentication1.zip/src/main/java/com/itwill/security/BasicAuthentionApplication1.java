package com.itwill.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicAuthentionApplication1 {

    public static void main(String[] args) {
        SpringApplication.run(BasicAuthentionApplication1.class, args);
    }

}
